#include "stm32f407xx.h"
#include "rx.h"

static volatile RxQueue queue;
static volatile Decoder decoder;
static volatile unsigned uart_errors;

/* Standalone startup using reset clock settings: PCLK1 = 16 MHz. */
static void uart_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
    (void)RCC->APB1ENR;
    GPIOA->MODER = (GPIOA->MODER & ~(3u << 6)) | (2u << 6);
    GPIOA->AFR[0] = (GPIOA->AFR[0] & ~(15u << 12)) | (7u << 12);
    GPIOA->PUPDR = (GPIOA->PUPDR & ~(3u << 6)) | (1u << 6);

    USART2->CR1 = 0;
    USART2->CR2 = 0;
    USART2->CR3 = 0;
    USART2->BRR = (16000000u + 115200u / 2u) / 115200u;
    USART2->CR1 = USART_CR1_UE | USART_CR1_RE | USART_CR1_RXNEIE;
    NVIC_EnableIRQ(USART2_IRQn);
}

void USART2_IRQHandler(void)
{
    uint32_t status = USART2->SR;
    const uint32_t errors = USART_SR_ORE | USART_SR_FE | USART_SR_NE | USART_SR_PE;
    if ((status & (errors | USART_SR_RXNE)) == 0u) return;
    uint8_t byte = (uint8_t)USART2->DR;
    if ((status & errors) != 0u) {
        ++uart_errors;
        queue.gap_pending = true;
        return;
    }
    rx_push(&queue, byte);
}

int main(void)
{
    uart_init();
    for (;;) {
        RxByte byte;
        uint32_t mask = __get_PRIMASK();
        __disable_irq();
        bool ready = rx_pop(&queue, &byte);
        __set_PRIMASK(mask);
        if (ready) decode(&decoder, byte);
    }
}
